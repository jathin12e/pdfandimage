import { A, e } from "./mermaid-parser.core.BCMcKKx9.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
