import { I, c } from "./mermaid-parser.core.BCMcKKx9.js";
export {
  I as InfoModule,
  c as createInfoServices
};
