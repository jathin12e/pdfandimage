import { G, f } from "./mermaid-parser.core.BCMcKKx9.js";
export {
  G as GitGraphModule,
  f as createGitGraphServices
};
