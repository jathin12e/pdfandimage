import { P, a } from "./mermaid-parser.core.BCMcKKx9.js";
export {
  P as PacketModule,
  a as createPacketServices
};
